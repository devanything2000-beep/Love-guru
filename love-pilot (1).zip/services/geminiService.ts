
import { GoogleGenAI } from "@google/genai";
import { SYSTEM_PROMPTS } from '../constants';
import { CoachSessionInput, CoachResponse, AvatarConfig, VideoCoachResponse } from '../types';

const getApiKey = () => {
  try {
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
      return process.env.API_KEY;
    }
  } catch (e) {}
  return '';
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

export const generateLoveCoachResponse = async (input: CoachSessionInput): Promise<CoachResponse | null> => {
  try {
    // Construct prompt with all new detailed fields
    let detailedContext = "";
    if (input.detailedLocation) {
        detailedContext += `\n- Detailed Location: ${input.detailedLocation.city}, ${input.detailedLocation.state}, ${input.detailedLocation.country} (Pincode: ${input.detailedLocation.pincode})`;
    }
    if (input.advancedContext) {
        detailedContext += `\n- User Personality: ${input.advancedContext.userPersonality}`;
        detailedContext += `\n- Partner Personality: ${input.advancedContext.partnerPersonality}`;
        detailedContext += `\n- Timing/Meeting Context: ${input.advancedContext.timing}`;
        detailedContext += `\n- Who they are with: ${input.advancedContext.company}`;
        detailedContext += `\n- Atmosphere: ${input.advancedContext.atmosphere}`;
    }

    const prompt = `
      User Situation:
      - Mood: ${input.mood}
      - Location Type: ${input.locationType}
      - Relationship Stage: ${input.stage}
      - Confidence Level: ${input.confidence}
      - Primary Obstacle: ${input.obstacleCategory} -> ${input.obstacleDetail}
      
      Detailed Context:
      ${detailedContext}
      
      Additional Notes:
      - Location Details (Legacy): ${input.context.locationDetails}
      - Surroundings (Legacy): ${input.context.surroundings}
      
      TASK: Provide advice in Hinglish (Hindi + English mix).
      RETURN JSON ONLY. Do not use Markdown code blocks.
      Structure:
      {
        "solution": "Psychology backed solution in 2-3 lines (Samadhan)",
        "script": "Exact dialogue to say (Bolne ke liye script)",
        "tone": "How to speak (Awaaz aur Tone)",
        "bodyLanguage": "Actionable body language tips (Body Language)",
        "bestTime": "Best time to execute this (Baat karne ke liye accha din)",
        "keyNote": "One crucial warning or tip (Khas baat)"
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPTS.loveCoach,
        temperature: 0.7,
        responseMimeType: "application/json"
      },
      contents: prompt,
    });
    
    if (response.text) {
        return JSON.parse(response.text) as CoachResponse;
    }
    return null;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};

export const generateVideoCoachResponse = async (
  userMessage: string, 
  config: AvatarConfig, 
  history: {role: string, text: string}[]
): Promise<VideoCoachResponse | null> => {
  try {
    const prompt = `
      You are LovePilot AI Video Call Coach.
      
      Your Identity:
      - Gender: ${config.gender}
      - Age: ${config.age}
      - Personality: ${config.personality}
      - Style: ${config.style}
      - Speaking Language: ${config.language} (Use Hinglish if selected)

      You MUST:
      - Listen to user text/voice input.
      - Reply every time.
      - Never stay silent.
      - Be warm, emotional, and motivating.
      - Act like a real video call romantic coach.

      User said: "${userMessage}"
      
      Task:
      1. Analyze the user's emotional state from their message.
      2. Reply naturally in ${config.language}.
      3. Give a psychological tip or specific advice on what to say.
      4. Determine which facial expression/emotion matches your reply (happy, serious, thinking, romantic, sad, confident).

      Output JSON ONLY:
      {
        "text": "Your spoken response here (Keep it under 3 sentences for video flow)...",
        "emotion": "happy" | "serious" | "thinking" | "surprised" | "empathetic" | "flirty" | "romantic" | "confident",
        "psychologyTip": "Short Psy Tip (e.g. Use the Push-Pull method)"
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: "You are an expert Relationship Psychologist & Video Coach. You speak naturally, show emotions, and guide users through love problems.",
        temperature: 0.7,
        responseMimeType: "application/json"
      },
      contents: prompt,
    });

    if (response.text) {
      return JSON.parse(response.text) as VideoCoachResponse;
    }
    return null;
  } catch (error) {
    console.error("Video Coach API Error:", error);
    return {
      text: "I'm having trouble hearing you. Can you say that again?",
      emotion: "thinking",
      psychologyTip: "Check Connection"
    };
  }
};

export const generateDailyGuidance = async (reflection: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: "You are a friendly, wise Indian Dating Coach (Love Pilot). Give a short, motivating, and psychology-backed piece of advice in Hinglish based on the user's daily reflection. Keep it under 60 words.",
        temperature: 0.8,
      },
      contents: `User's Reflection: "${reflection}"`,
    });
    return response.text || "Keep going, you are doing great!";
  } catch (error) {
    return "Error generating guidance.";
  }
};

export const generateTechniqueGuide = async (techniqueName: string, context: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: "You are an expert Social Psychologist. Explain how to apply a specific technique in a specific context. Keep it practical, step-by-step, and in Hinglish.",
        temperature: 0.7,
      },
      contents: `Technique: ${techniqueName}. Context/Situation: ${context}. Explain how to use this technique here.`,
    });
    return response.text || "Could not generate technique guide.";
  } catch (error) {
    return "Error generating guide.";
  }
};

export const generateDatePlan = async (city: string, vibe: string, vibe2: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPTS.datePlanner,
        temperature: 0.8,
      },
      contents: `Plan a date in ${city}. Vibe: ${vibe}. Budget: ${vibe2}.`,
    });
    return response.text || "Generating plan...";
  } catch (error) {
    return "Could not generate plan.";
  }
};

export const generateProfileReview = async (bio: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPTS.profileRoaster,
        temperature: 0.9,
      },
      contents: `Review this bio: "${bio}"`,
    });
    return response.text || "Analyzing...";
  } catch (error) {
    return "Could not review profile.";
  }
};

export const generatePracticeResponse = async (history: {role: string, content: string}[], scenario: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: `${SYSTEM_PROMPTS.practiceMode} Scenario: ${scenario}`,
        temperature: 0.8,
      },
      contents: { role: 'user', parts: [{ text: history[history.length - 1].content }] },
    });
    return response.text || "...";
  } catch (error) {
    return "(Silence...)";
  }
};

export const generateMessageSuggestions = async (context: string, tone: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPTS.messageHelper,
        temperature: 0.7,
      },
      contents: `Context: ${context}. Tone: ${tone}. Generate 3 options.`,
    });
    return response.text || "Suggestions unavailable.";
  } catch (error) {
    return "Error generating suggestions.";
  }
};

export const generateCaption = async (description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPTS.captionGenerator,
        temperature: 0.8,
      },
      contents: `Photo Description: ${description}`,
    });
    return response.text || "Caption unavailable.";
  } catch (error) {
    return "Error generating caption.";
  }
};

export const generateFetcherResponse = async (model: string, prompt: string, systemInstruction: string) => {
  try {
    const response = await ai.models.generateContent({
      model: model,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
      contents: prompt,
    });
    return response;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return { text: "I encountered an error processing your request." };
  }
};
